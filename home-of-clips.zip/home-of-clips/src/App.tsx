import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { ThemeProvider } from '@/contexts/ThemeContext'
import { AuthProvider } from '@/contexts/AuthContext'
import { ToastProvider } from '@/components/ui/Toast'
import { Navbar } from '@/components/ui/Navbar'
import { HomePage } from '@/pages/public/HomePage'
import { MoviePage } from '@/pages/public/MoviePage'
import { LoginPage } from '@/pages/admin/LoginPage'
import { DashboardPage } from '@/pages/admin/DashboardPage'
import { ProtectedRoute } from '@/components/admin/ProtectedRoute'
import { NotFoundPage } from '@/pages/NotFoundPage'

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-cinema-950 transition-colors duration-300">
      <Navbar />
      <div className="flex-1">{children}</div>
      <footer className="py-6 text-center text-xs text-gray-400 dark:text-gray-600 font-body border-t border-gray-100 dark:border-white/5 bg-white dark:bg-cinema-950">
        © {new Date().getFullYear()} Home of Clips — All rights reserved
      </footer>
    </div>
  )
}

export function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          <ToastProvider>
            <Routes>
              {/* Public */}
              <Route path="/" element={<Layout><HomePage /></Layout>} />
              <Route path="/movie/:id" element={<Layout><MoviePage /></Layout>} />

              {/* Admin auth (no nav layout for login) */}
              <Route path="/admin/login" element={<LoginPage />} />

              {/* Protected admin */}
              <Route
                path="/admin"
                element={
                  <ProtectedRoute>
                    <Layout>
                      <DashboardPage />
                    </Layout>
                  </ProtectedRoute>
                }
              />

              {/* 404 */}
              <Route path="*" element={<Layout><NotFoundPage /></Layout>} />
            </Routes>
          </ToastProvider>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  )
}
