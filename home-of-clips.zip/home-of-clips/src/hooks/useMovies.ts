import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import { Movie, MovieInsert, MovieUpdate } from '@/types'

export function useMovies(searchQuery?: string) {
  const [movies, setMovies] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchMovies = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      let query = supabase
        .from('movies')
        .select('*')
        .order('created_at', { ascending: false })

      if (searchQuery && searchQuery.trim()) {
        query = query.ilike('title', `%${searchQuery.trim()}%`)
      }

      const { data, error: err } = await query
      if (err) throw err
      setMovies(data ?? [])
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to fetch movies')
    } finally {
      setLoading(false)
    }
  }, [searchQuery])

  useEffect(() => {
    fetchMovies()
  }, [fetchMovies])

  return { movies, loading, error, refetch: fetchMovies }
}

export function useMovie(id: string) {
  const [movie, setMovie] = useState<Movie | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    setLoading(true)
    supabase
      .from('movies')
      .select('*')
      .eq('id', id)
      .single()
      .then(({ data, error: err }) => {
        if (err) setError(err.message)
        else setMovie(data)
        setLoading(false)
      })
  }, [id])

  return { movie, loading, error }
}

export async function createMovie(movie: MovieInsert) {
  const { data, error } = await supabase
    .from('movies')
    .insert([movie])
    .select()
    .single()
  return { data, error }
}

export async function updateMovie(id: string, updates: MovieUpdate) {
  const { data, error } = await supabase
    .from('movies')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  return { data, error }
}

export async function deleteMovie(id: string) {
  const { error } = await supabase.from('movies').delete().eq('id', id)
  return { error }
}
