import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { App } from './App'

const root = document.getElementById('root')
if (!root) {
  document.body.innerHTML = '<div style="font-family:sans-serif;padding:2rem;color:red">Fatal: #root element not found</div>'
} else {
  createRoot(root).render(
    <StrictMode>
      <App />
    </StrictMode>
  )
}
