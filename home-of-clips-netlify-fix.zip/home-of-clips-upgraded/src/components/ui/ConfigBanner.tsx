import { AlertTriangle } from 'lucide-react'
import { isMissingConfig } from '@/lib/supabase'

export function ConfigBanner() {
  if (!isMissingConfig) return null
  return (
    <div className="fixed top-0 inset-x-0 z-[200] bg-amber-500 text-amber-950 px-4 py-2.5 flex items-center justify-center gap-2 text-sm font-body font-medium shadow-lg">
      <AlertTriangle className="w-4 h-4 shrink-0" />
      Supabase environment variables are not configured. Set{' '}
      <code className="font-mono bg-amber-400/40 px-1 rounded">VITE_SUPABASE_URL</code> and{' '}
      <code className="font-mono bg-amber-400/40 px-1 rounded">VITE_SUPABASE_ANON_KEY</code>{' '}
      in your Netlify site settings.
    </div>
  )
}
