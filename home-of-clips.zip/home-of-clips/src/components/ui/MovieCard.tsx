import { Link } from 'react-router-dom'
import { Calendar } from 'lucide-react'
import { Movie } from '@/types'

interface MovieCardProps {
  movie: Movie
  index?: number
}

export function MovieCard({ movie, index = 0 }: MovieCardProps) {
  return (
    <Link
      to={`/movie/${movie.id}`}
      className="group block animate-slide-up"
      style={{ animationDelay: `${index * 60}ms`, animationFillMode: 'both' }}
    >
      <div className="relative overflow-hidden rounded-xl bg-gray-100 dark:bg-cinema-800 border border-gray-200/60 dark:border-white/5 hover:border-brand-500/40 transition-all duration-300 hover:shadow-2xl hover:shadow-brand-500/10 hover:-translate-y-1">
        {/* Poster */}
        <div className="relative aspect-[2/3] overflow-hidden bg-gray-200 dark:bg-cinema-700">
          {movie.poster_url ? (
            <img
              src={movie.poster_url}
              alt={movie.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              loading="lazy"
              onError={(e) => {
                const t = e.currentTarget
                t.style.display = 'none'
                t.nextElementSibling?.classList.remove('hidden')
              }}
            />
          ) : null}
          {/* Fallback */}
          <div className={`${movie.poster_url ? 'hidden' : 'flex'} absolute inset-0 items-center justify-center flex-col gap-2`}>
            <div className="w-12 h-12 rounded-full bg-brand-500/20 flex items-center justify-center">
              <span className="text-brand-500 text-xl font-display">{movie.title[0]}</span>
            </div>
          </div>

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Language badge */}
          <div className="absolute top-2 right-2">
            <span className="px-2 py-0.5 text-xs font-mono font-medium bg-black/60 backdrop-blur-sm text-white/90 rounded-md border border-white/10">
              {movie.language}
            </span>
          </div>
        </div>

        {/* Info */}
        <div className="p-3">
          <h3 className="font-body font-semibold text-sm text-gray-900 dark:text-white line-clamp-2 leading-snug group-hover:text-brand-500 dark:group-hover:text-brand-400 transition-colors">
            {movie.title}
          </h3>
          <div className="mt-1.5 flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
            <Calendar className="w-3 h-3" />
            <span>{movie.release_year}</span>
          </div>
        </div>
      </div>
    </Link>
  )
}

export function MovieCardSkeleton() {
  return (
    <div className="rounded-xl overflow-hidden bg-gray-100 dark:bg-cinema-800 border border-gray-200 dark:border-white/5 animate-pulse">
      <div className="aspect-[2/3] bg-gray-200 dark:bg-cinema-700" />
      <div className="p-3 space-y-2">
        <div className="h-4 bg-gray-200 dark:bg-cinema-700 rounded w-3/4" />
        <div className="h-3 bg-gray-200 dark:bg-cinema-700 rounded w-1/3" />
      </div>
    </div>
  )
}
