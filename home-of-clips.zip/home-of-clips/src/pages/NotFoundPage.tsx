import { Link } from 'react-router-dom'
import { Film, Home } from 'lucide-react'
import { Button } from '@/components/ui/Button'

export function NotFoundPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-cinema-950 flex items-center justify-center p-4">
      <div className="text-center animate-fade-in">
        <div className="inline-flex w-20 h-20 bg-gray-100 dark:bg-cinema-800 rounded-3xl items-center justify-center mb-6">
          <Film className="w-10 h-10 text-gray-300 dark:text-gray-600" />
        </div>
        <h1 className="font-display text-8xl text-gray-200 dark:text-cinema-800 mb-2">404</h1>
        <h2 className="font-body font-semibold text-xl text-gray-700 dark:text-gray-300 mb-2">Page not found</h2>
        <p className="text-gray-400 dark:text-gray-500 text-sm mb-8 max-w-xs mx-auto">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link to="/">
          <Button icon={<Home className="w-4 h-4" />} size="lg">
            Back to Home
          </Button>
        </Link>
      </div>
    </div>
  )
}
