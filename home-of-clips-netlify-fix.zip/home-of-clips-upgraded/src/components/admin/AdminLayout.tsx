import { ReactNode, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import {
  Film, LayoutDashboard, Users, Settings, LogOut,
  Menu, X, ChevronRight, Sun, Moon, Home
} from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { useTheme } from '@/contexts/ThemeContext'

interface NavItem {
  to: string
  icon: ReactNode
  label: string
  badge?: number
}

interface AdminLayoutProps {
  children: ReactNode
  movieCount?: number
  adminCount?: number
}

export function AdminLayout({ children, movieCount, adminCount }: AdminLayoutProps) {
  const { user, signOut } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const navigate = useNavigate()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const navItems: NavItem[] = [
    { to: '/admin', icon: <LayoutDashboard className="w-4.5 h-4.5" />, label: 'Movies', badge: movieCount },
    { to: '/admin/users', icon: <Users className="w-4.5 h-4.5" />, label: 'Admins', badge: adminCount },
    { to: '/admin/settings', icon: <Settings className="w-4.5 h-4.5" />, label: 'Settings' },
  ]

  const handleSignOut = async () => {
    await signOut()
    navigate('/')
  }

  const isActive = (to: string) => {
    if (to === '/admin') return location.pathname === '/admin'
    return location.pathname.startsWith(to)
  }

  const Sidebar = ({ mobile = false }) => (
    <aside className={`
      ${mobile
        ? 'fixed inset-0 z-50 flex'
        : 'hidden lg:flex w-60 shrink-0'
      }
    `}>
      {mobile && (
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      <div className={`
        relative flex flex-col h-full bg-cinema-950 border-r border-white/10
        ${mobile ? 'w-64 shadow-2xl' : 'w-60'}
      `}>
        {/* Logo */}
        <div className="flex items-center justify-between px-5 h-16 border-b border-white/10 shrink-0">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center shadow-lg shadow-brand-500/30">
              <Film className="w-4 h-4 text-white" />
            </div>
            <span className="font-display text-lg tracking-wider text-white leading-none">
              HOC<span className="text-brand-500">.</span>
            </span>
          </Link>
          {mobile && (
            <button
              onClick={() => setSidebarOpen(false)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Admin Badge */}
        <div className="px-4 py-4 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-brand-500/20 border border-brand-500/30 flex items-center justify-center shrink-0">
              <span className="text-brand-400 text-xs font-mono font-bold uppercase">
                {user?.email?.[0] ?? 'A'}
              </span>
            </div>
            <div className="min-w-0">
              <p className="text-xs font-body text-white/80 truncate">{user?.email}</p>
              <span className="text-[10px] font-mono text-brand-400 bg-brand-500/10 px-1.5 py-0.5 rounded tracking-wider">
                ADMIN
              </span>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          <p className="px-2 pb-2 text-[10px] font-mono text-gray-600 uppercase tracking-widest">Panel</p>
          {navItems.map(item => (
            <Link
              key={item.to}
              to={item.to}
              onClick={() => setSidebarOpen(false)}
              className={`
                flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-body transition-all group
                ${isActive(item.to)
                  ? 'bg-brand-500/15 text-brand-400 border border-brand-500/20'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
                }
              `}
            >
              <div className="flex items-center gap-2.5">
                {item.icon}
                {item.label}
              </div>
              <div className="flex items-center gap-2">
                {item.badge !== undefined && (
                  <span className={`text-xs font-mono px-1.5 py-0.5 rounded-md ${
                    isActive(item.to)
                      ? 'bg-brand-500/20 text-brand-400'
                      : 'bg-white/5 text-gray-500'
                  }`}>
                    {item.badge}
                  </span>
                )}
                {isActive(item.to) && <ChevronRight className="w-3.5 h-3.5 text-brand-400" />}
              </div>
            </Link>
          ))}

          <div className="pt-4">
            <p className="px-2 pb-2 text-[10px] font-mono text-gray-600 uppercase tracking-widest">Quick</p>
            <Link
              to="/"
              className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-body text-gray-400 hover:text-white hover:bg-white/5 transition-all"
            >
              <Home className="w-4.5 h-4.5" />
              View Site
            </Link>
          </div>
        </nav>

        {/* Footer */}
        <div className="px-3 pb-4 pt-2 border-t border-white/10 space-y-1">
          <button
            onClick={toggleTheme}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-body text-gray-400 hover:text-white hover:bg-white/5 transition-all"
          >
            {theme === 'dark'
              ? <><Sun className="w-4.5 h-4.5" />Light Mode</>
              : <><Moon className="w-4.5 h-4.5" />Dark Mode</>
            }
          </button>
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-body text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all"
          >
            <LogOut className="w-4.5 h-4.5" />
            Sign Out
          </button>
        </div>
      </div>
    </aside>
  )

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50 dark:bg-cinema-950">
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Mobile sidebar overlay */}
      {sidebarOpen && <Sidebar mobile />}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Mobile topbar */}
        <header className="lg:hidden flex items-center justify-between px-4 h-14 bg-cinema-950 border-b border-white/10 shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-display text-sm tracking-widest text-white">
            HOME<span className="text-brand-500">OF</span>CLIPS
          </span>
          <div className="w-5" />
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  )
}
