import { useState } from 'react'
import { Film, Clapperboard, Zap, Search } from 'lucide-react'
import { SearchBar } from '@/components/ui/SearchBar'
import { MovieCard, MovieCardSkeleton } from '@/components/ui/MovieCard'
import { useMovies } from '@/hooks/useMovies'
import { useDebounce } from '@/hooks/useDebounce'

export function HomePage() {
  const [query, setQuery] = useState('')
  const debouncedQuery = useDebounce(query, 280)
  const { movies, loading, error } = useMovies(debouncedQuery)

  const isSearching = !!debouncedQuery.trim()

  return (
    <main className="min-h-screen bg-gray-50 dark:bg-cinema-950 transition-colors duration-300">
      {/* Hero */}
      <section className="relative overflow-hidden bg-cinema-950 dark:bg-cinema-950 py-16 sm:py-24">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-32 -right-32 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-brand-600/10 rounded-full blur-3xl" />
          {/* Film strip decoration */}
          <div className="absolute inset-y-0 left-0 w-8 flex flex-col gap-1 opacity-10">
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} className="w-full h-6 bg-white rounded-sm flex-shrink-0" />
            ))}
          </div>
          <div className="absolute inset-y-0 right-0 w-8 flex flex-col gap-1 opacity-10">
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} className="w-full h-6 bg-white rounded-sm flex-shrink-0" />
            ))}
          </div>
        </div>

        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/15 border border-brand-500/25 text-brand-400 text-xs font-mono font-medium mb-6 animate-fade-in">
            <Clapperboard className="w-3.5 h-3.5" />
            MOVIE CLIP LIBRARY
          </div>

          {/* Headline */}
          <h1 className="font-display text-5xl sm:text-7xl text-white tracking-wider mb-4 animate-slide-up leading-none">
            HOME<span className="text-brand-500">OF</span>CLIPS
          </h1>

          <p className="text-gray-400 font-body text-base sm:text-lg mb-8 animate-slide-up max-w-lg mx-auto" style={{ animationDelay: '80ms', animationFillMode: 'both' }}>
            Your curated library of cinematic dialogues and iconic slow-motion clips.
          </p>

          {/* Feature pills */}
          <div className="flex flex-wrap justify-center gap-2 mb-10 animate-slide-up" style={{ animationDelay: '140ms', animationFillMode: 'both' }}>
            {[
              { icon: Film, label: 'Dialogues' },
              { icon: Zap, label: 'Slow Mo Clips' },
              { icon: Search, label: 'Fast Search' },
            ].map(({ icon: Icon, label }) => (
              <span key={label} className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-xs text-gray-300 font-body">
                <Icon className="w-3.5 h-3.5 text-brand-400" />
                {label}
              </span>
            ))}
          </div>

          {/* Search */}
          <div className="animate-slide-up max-w-xl mx-auto" style={{ animationDelay: '200ms', animationFillMode: 'both' }}>
            <SearchBar
              value={query}
              onChange={setQuery}
              placeholder="Search by movie title…"
            />
          </div>
        </div>
      </section>

      {/* Movies Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Section header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="font-body font-semibold text-gray-900 dark:text-white text-lg">
              {isSearching ? `Results for "${debouncedQuery}"` : 'All Movies'}
            </h2>
            {!loading && (
              <p className="text-sm text-gray-400 dark:text-gray-500 mt-0.5">
                {movies.length} {movies.length === 1 ? 'movie' : 'movies'}
              </p>
            )}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/20 flex items-center justify-center mx-auto mb-3">
                <Film className="w-6 h-6 text-red-500" />
              </div>
              <p className="text-gray-500 dark:text-gray-400 font-body text-sm">{error}</p>
            </div>
          </div>
        )}

        {/* Loading skeleton */}
        {loading && !error && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {Array.from({ length: 12 }).map((_, i) => (
              <MovieCardSkeleton key={i} />
            ))}
          </div>
        )}

        {/* Empty state */}
        {!loading && !error && movies.length === 0 && (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-cinema-800 flex items-center justify-center mb-4">
              <Clapperboard className="w-8 h-8 text-gray-300 dark:text-gray-600" />
            </div>
            <h3 className="font-body font-semibold text-gray-700 dark:text-gray-300 mb-1">
              {isSearching ? 'No movies found' : 'No movies yet'}
            </h3>
            <p className="text-sm text-gray-400 dark:text-gray-500 max-w-xs">
              {isSearching
                ? `Try a different search term.`
                : 'Movies will appear here once added by an admin.'}
            </p>
          </div>
        )}

        {/* Grid */}
        {!loading && !error && movies.length > 0 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {movies.map((movie, i) => (
              <MovieCard key={movie.id} movie={movie} index={i} />
            ))}
          </div>
        )}
      </section>
    </main>
  )
}
