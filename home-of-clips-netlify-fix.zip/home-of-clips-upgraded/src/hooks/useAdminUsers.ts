import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import { AdminUser } from '@/types'

export function useAdminUsers() {
  const [admins, setAdmins] = useState<AdminUser[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchAdmins = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const { data, error: err } = await supabase
        .from('admin_users')
        .select('*')
        .order('created_at', { ascending: false })
      if (err) throw err
      setAdmins(data ?? [])
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to fetch admins')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchAdmins() }, [fetchAdmins])

  return { admins, loading, error, refetch: fetchAdmins }
}

export async function addAdminUser(email: string) {
  const { data, error } = await supabase
    .from('admin_users')
    .insert([{ email: email.toLowerCase().trim() }])
    .select()
    .single()
  return { data, error }
}

export async function removeAdminUser(id: string) {
  const { error } = await supabase.from('admin_users').delete().eq('id', id)
  return { error }
}
