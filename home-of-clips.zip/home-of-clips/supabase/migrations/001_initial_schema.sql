-- ============================================================
-- Home of Clips — Supabase Database Schema + RLS Policies
-- Run this in: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- ── 1. EXTENSIONS ────────────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── 2. TABLES ────────────────────────────────────────────────

-- movies
create table if not exists public.movies (
  id              uuid primary key default uuid_generate_v4(),
  title           text not null,
  poster_url      text not null default '',
  release_year    integer not null,
  language        text not null,
  dialogues_folder_url  text not null,
  slowmo_folder_url     text not null,
  created_at      timestamptz not null default now()
);

comment on table public.movies is 'Manually curated movie records with Google Drive clip folders.';

-- admin_users
create table if not exists public.admin_users (
  id          uuid primary key default uuid_generate_v4(),
  email       text not null unique,
  created_at  timestamptz not null default now()
);

comment on table public.admin_users is 'Approved admin email addresses. Only these users can manage movies.';

-- ── 3. INDEXES ───────────────────────────────────────────────
create index if not exists movies_title_idx on public.movies using gin (to_tsvector('english', title));
create index if not exists movies_created_at_idx on public.movies (created_at desc);

-- ── 4. ROW LEVEL SECURITY ────────────────────────────────────

alter table public.movies enable row level security;
alter table public.admin_users enable row level security;

-- Drop existing policies to allow re-running cleanly
drop policy if exists "movies_public_select" on public.movies;
drop policy if exists "movies_admin_insert" on public.movies;
drop policy if exists "movies_admin_update" on public.movies;
drop policy if exists "movies_admin_delete" on public.movies;
drop policy if exists "admin_users_self_select" on public.admin_users;
drop policy if exists "admin_users_admin_select" on public.admin_users;

-- MOVIES: anyone can read
create policy "movies_public_select"
  on public.movies for select
  using (true);

-- Helper: check if the calling user is an admin
create or replace function public.is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1
    from public.admin_users
    where email = auth.jwt() ->> 'email'
  );
$$;

-- MOVIES: only admins can insert / update / delete
create policy "movies_admin_insert"
  on public.movies for insert
  with check (public.is_admin());

create policy "movies_admin_update"
  on public.movies for update
  using (public.is_admin());

create policy "movies_admin_delete"
  on public.movies for delete
  using (public.is_admin());

-- ADMIN_USERS: authenticated users can check if their email is in the list
create policy "admin_users_self_select"
  on public.admin_users for select
  using (auth.role() = 'authenticated');

-- ── 5. SEED — insert your first admin ────────────────────────
-- Replace with the email address you will use to sign up:
-- insert into public.admin_users (email) values ('your-admin@example.com');
--
-- After inserting, create the matching account in:
-- Supabase Dashboard → Authentication → Users → Invite user
-- (or use the Sign Up flow, then add the email here)

-- ── 6. OPTIONAL: Full-text search helper ─────────────────────
create or replace function public.search_movies(query text)
returns setof public.movies
language sql
stable
as $$
  select *
  from public.movies
  where title ilike '%' || query || '%'
  order by created_at desc;
$$;
