import { useState } from 'react'
import { Plus, Trash2, Shield, ShieldOff, Mail, RefreshCw, UserCheck } from 'lucide-react'
import { useAdminUsers, addAdminUser, removeAdminUser } from '@/hooks/useAdminUsers'
import { useAuth } from '@/contexts/AuthContext'
import { useMovies } from '@/hooks/useMovies'
import { Button } from '@/components/ui/Button'
import { Modal } from '@/components/ui/Modal'
import { useToast } from '@/components/ui/Toast'
import { AdminLayout } from '@/components/admin/AdminLayout'

export function AdminUsersPage() {
  const { admins, loading, error, refetch } = useAdminUsers()
  const { movies } = useMovies()
  const { user: currentUser } = useAuth()
  const { toast } = useToast()

  const [addOpen, setAddOpen] = useState(false)
  const [removeTarget, setRemoveTarget] = useState<{ id: string; email: string } | null>(null)
  const [newEmail, setNewEmail] = useState('')
  const [emailError, setEmailError] = useState('')
  const [saving, setSaving] = useState(false)
  const [removing, setRemoving] = useState(false)

  const handleAdd = async () => {
    setEmailError('')
    const trimmed = newEmail.trim().toLowerCase()
    if (!trimmed) { setEmailError('Email is required'); return }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) { setEmailError('Enter a valid email address'); return }
    if (admins.some(a => a.email === trimmed)) { setEmailError('This email is already an admin'); return }

    setSaving(true)
    const { error: err } = await addAdminUser(trimmed)
    setSaving(false)
    if (err) { toast(err.message, 'error') }
    else {
      toast(`${trimmed} added as admin.`, 'success')
      setNewEmail('')
      setAddOpen(false)
      refetch()
    }
  }

  const handleRemove = async () => {
    if (!removeTarget) return
    setRemoving(true)
    const { error: err } = await removeAdminUser(removeTarget.id)
    setRemoving(false)
    if (err) { toast(err.message, 'error') }
    else {
      toast(`${removeTarget.email} removed.`, 'success')
      setRemoveTarget(null)
      refetch()
    }
  }

  const isSelf = (email: string) => email === currentUser?.email

  return (
    <AdminLayout movieCount={movies.length} adminCount={admins.length}>
      <div className="p-6 lg:p-8 max-w-4xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl text-gray-900 dark:text-white tracking-wider">ADMINS</h1>
            <p className="text-gray-400 dark:text-gray-500 text-sm font-body mt-0.5">
              {admins.length} admin{admins.length !== 1 ? 's' : ''} with dashboard access
            </p>
          </div>
          <Button onClick={() => setAddOpen(true)} icon={<Plus className="w-4 h-4" />}>
            Add Admin
          </Button>
        </div>

        {/* Info card */}
        <div className="bg-brand-50 dark:bg-brand-500/10 border border-brand-200 dark:border-brand-500/20 rounded-xl p-4 flex gap-3">
          <Shield className="w-5 h-5 text-brand-500 dark:text-brand-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-body font-medium text-brand-700 dark:text-brand-300 mb-0.5">How admin access works</p>
            <p className="text-xs font-body text-brand-600/80 dark:text-brand-400/80">
              Add an email here, then create a matching account via Supabase Auth → Users. Only emails listed here can access this dashboard.
            </p>
          </div>
        </div>

        {/* Admin list */}
        <div className="bg-white dark:bg-cinema-900 rounded-2xl border border-gray-200 dark:border-white/10 overflow-hidden shadow-sm">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100 dark:border-white/5">
            <p className="text-xs font-mono text-gray-400 uppercase tracking-wider">Admin Accounts</p>
            <button
              onClick={refetch}
              className="p-1.5 rounded-lg text-gray-400 hover:text-brand-500 transition-colors"
              title="Refresh"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {error && <div className="p-6 text-center text-sm text-red-500 font-body">{error}</div>}

          {loading && !error && (
            <div className="p-10 flex items-center justify-center">
              <div className="w-7 h-7 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {!loading && !error && admins.length === 0 && (
            <div className="p-10 text-center">
              <ShieldOff className="w-9 h-9 text-gray-200 dark:text-gray-700 mx-auto mb-3" />
              <p className="text-gray-400 dark:text-gray-500 text-sm font-body">No admins yet.</p>
            </div>
          )}

          {!loading && !error && admins.length > 0 && (
            <ul className="divide-y divide-gray-50 dark:divide-white/5">
              {admins.map(admin => (
                <li key={admin.id} className="flex items-center justify-between px-5 py-4 hover:bg-gray-50 dark:hover:bg-cinema-800/50 transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-full bg-brand-500/10 border border-brand-500/20 flex items-center justify-center shrink-0">
                      <span className="text-brand-500 dark:text-brand-400 text-sm font-mono font-bold uppercase">
                        {admin.email[0]}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-body text-sm text-gray-900 dark:text-white truncate">{admin.email}</p>
                        {isSelf(admin.email) && (
                          <span className="text-[10px] font-mono text-brand-500 bg-brand-50 dark:bg-brand-500/10 px-1.5 py-0.5 rounded tracking-wider shrink-0">YOU</span>
                        )}
                      </div>
                      <p className="text-xs font-body text-gray-400 dark:text-gray-500">
                        Added {new Date(admin.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="hidden sm:flex items-center gap-1 text-xs font-body text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-500/10 px-2 py-1 rounded-md">
                      <UserCheck className="w-3 h-3" />
                      Active
                    </span>
                    {!isSelf(admin.email) && (
                      <button
                        onClick={() => setRemoveTarget({ id: admin.id, email: admin.email })}
                        className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all"
                        title="Remove admin"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Add Modal */}
      <Modal open={addOpen} onClose={() => { setAddOpen(false); setNewEmail(''); setEmailError('') }} title="Add Admin" size="sm">
        <div className="space-y-4">
          <p className="text-sm font-body text-gray-500 dark:text-gray-400">
            Enter the email address of the person you want to grant admin access. They must also have a Supabase Auth account with this email.
          </p>
          <div className="space-y-1.5">
            <label className="text-xs font-mono text-gray-400 uppercase tracking-wider">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="email"
                value={newEmail}
                onChange={e => { setNewEmail(e.target.value); setEmailError('') }}
                onKeyDown={e => e.key === 'Enter' && handleAdd()}
                placeholder="admin@example.com"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all font-body"
              />
            </div>
            {emailError && <p className="text-xs text-red-500 font-body">{emailError}</p>}
          </div>
          <div className="flex gap-3">
            <Button onClick={handleAdd} loading={saving} className="flex-1">Add Admin</Button>
            <Button variant="secondary" onClick={() => { setAddOpen(false); setNewEmail(''); setEmailError('') }} disabled={saving}>Cancel</Button>
          </div>
        </div>
      </Modal>

      {/* Remove confirm */}
      <Modal open={!!removeTarget} onClose={() => setRemoveTarget(null)} title="Remove Admin" size="sm">
        <div className="space-y-4">
          <p className="text-sm font-body text-gray-600 dark:text-gray-300">
            Remove <strong className="text-gray-900 dark:text-white">{removeTarget?.email}</strong> from admin access?
            They will no longer be able to sign in to this dashboard.
          </p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={handleRemove} loading={removing} className="flex-1">Remove</Button>
            <Button variant="secondary" onClick={() => setRemoveTarget(null)} disabled={removing}>Cancel</Button>
          </div>
        </div>
      </Modal>
    </AdminLayout>
  )
}
