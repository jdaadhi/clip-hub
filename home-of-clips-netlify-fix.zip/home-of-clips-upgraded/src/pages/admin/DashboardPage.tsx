import { useState, useMemo } from 'react'
import {
  Plus, Pencil, Trash2, Film, Search, ExternalLink,
  RefreshCw, Filter, ChevronDown, CheckSquare, Square,
  Globe, Calendar, Layers
} from 'lucide-react'
import { useMovies, createMovie, updateMovie, deleteMovie } from '@/hooks/useMovies'
import { useAdminUsers } from '@/hooks/useAdminUsers'
import { Movie, MovieInsert } from '@/types'
import { Button } from '@/components/ui/Button'
import { Modal } from '@/components/ui/Modal'
import { MovieForm } from '@/components/admin/MovieForm'
import { useToast } from '@/components/ui/Toast'
import { AdminLayout } from '@/components/admin/AdminLayout'

type SortField = 'title' | 'release_year' | 'language' | 'created_at'
type SortDir = 'asc' | 'desc'

function StatCard({ icon, label, value, sub }: {
  icon: React.ReactNode
  label: string
  value: string | number
  sub?: string
}) {
  return (
    <div className="bg-white dark:bg-cinema-900 border border-gray-200 dark:border-white/10 rounded-2xl p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-mono text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-1">{label}</p>
          <p className="font-display text-3xl text-gray-900 dark:text-white tracking-wide">{value}</p>
          {sub && <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 font-body">{sub}</p>}
        </div>
        <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-500/10 flex items-center justify-center text-brand-500 dark:text-brand-400">
          {icon}
        </div>
      </div>
    </div>
  )
}

export function DashboardPage() {
  const { movies, loading, error, refetch } = useMovies()
  const { admins } = useAdminUsers()
  const { toast } = useToast()

  const [search, setSearch] = useState('')
  const [langFilter, setLangFilter] = useState('')
  const [sortField, setSortField] = useState<SortField>('created_at')
  const [sortDir, setSortDir] = useState<SortDir>('desc')
  const [showFilters, setShowFilters] = useState(false)

  const [addOpen, setAddOpen] = useState(false)
  const [editMovie, setEditMovie] = useState<Movie | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Movie | null>(null)
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const [selected, setSelected] = useState<Set<string>>(new Set())

  // Derived stats
  const languages = useMemo(() => [...new Set(movies.map(m => m.language))].sort(), [movies])
  const years = useMemo(() => [...new Set(movies.map(m => m.release_year))].sort((a, b) => b - a), [movies])

  // Filtered + sorted
  const filtered = useMemo(() => {
    let list = movies.filter(m => {
      const matchSearch = m.title.toLowerCase().includes(search.toLowerCase())
      const matchLang = langFilter ? m.language === langFilter : true
      return matchSearch && matchLang
    })
    list = [...list].sort((a, b) => {
      const va = a[sortField] ?? ''
      const vb = b[sortField] ?? ''
      if (va < vb) return sortDir === 'asc' ? -1 : 1
      if (va > vb) return sortDir === 'asc' ? 1 : -1
      return 0
    })
    return list
  }, [movies, search, langFilter, sortField, sortDir])

  const allChecked = filtered.length > 0 && filtered.every(m => selected.has(m.id))
  const someChecked = filtered.some(m => selected.has(m.id))

  const toggleAll = () => {
    if (allChecked) {
      setSelected(new Set())
    } else {
      setSelected(new Set(filtered.map(m => m.id)))
    }
  }

  const toggleOne = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const handleSort = (field: SortField) => {
    if (field === sortField) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDir('asc')
    }
  }

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronDown className="w-3 h-3 text-gray-300 dark:text-gray-600" />
    return <ChevronDown className={`w-3 h-3 text-brand-500 transition-transform ${sortDir === 'asc' ? 'rotate-180' : ''}`} />
  }

  const handleAdd = async (data: MovieInsert) => {
    setSaving(true)
    const { error: err } = await createMovie(data)
    setSaving(false)
    if (err) { toast(err.message, 'error') }
    else { toast('Movie added!', 'success'); setAddOpen(false); refetch() }
  }

  const handleEdit = async (data: MovieInsert) => {
    if (!editMovie) return
    setSaving(true)
    const { error: err } = await updateMovie(editMovie.id, data)
    setSaving(false)
    if (err) { toast(err.message, 'error') }
    else { toast('Movie updated!', 'success'); setEditMovie(null); refetch() }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    const { error: err } = await deleteMovie(deleteTarget.id)
    setDeleting(false)
    if (err) { toast(err.message, 'error') }
    else { toast('Movie deleted.', 'success'); setDeleteTarget(null); refetch() }
  }

  const handleBulkDelete = async () => {
    setDeleting(true)
    let failed = 0
    for (const id of selected) {
      const { error: err } = await deleteMovie(id)
      if (err) failed++
    }
    setDeleting(false)
    setBulkDeleteOpen(false)
    setSelected(new Set())
    if (failed > 0) toast(`${failed} movies failed to delete.`, 'error')
    else toast(`${selected.size} movies deleted.`, 'success')
    refetch()
  }

  return (
    <AdminLayout movieCount={movies.length} adminCount={admins.length}>
      <div className="p-6 lg:p-8 max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl text-gray-900 dark:text-white tracking-wider">MOVIES</h1>
            <p className="text-gray-400 dark:text-gray-500 text-sm font-body mt-0.5">
              {movies.length} total · {languages.length} language{languages.length !== 1 ? 's' : ''}
            </p>
          </div>
          <Button onClick={() => setAddOpen(true)} icon={<Plus className="w-4 h-4" />}>
            Add Movie
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={<Film className="w-5 h-5" />} label="Total Movies" value={movies.length} />
          <StatCard icon={<Globe className="w-5 h-5" />} label="Languages" value={languages.length} sub={languages.slice(0, 2).join(', ') + (languages.length > 2 ? '…' : '')} />
          <StatCard icon={<Calendar className="w-5 h-5" />} label="Years Covered" value={years.length} sub={years.length > 0 ? `${years[years.length - 1]}–${years[0]}` : '—'} />
          <StatCard icon={<Layers className="w-5 h-5" />} label="Drive Folders" value={movies.length * 2} sub="Dialogues + Slow Mo" />
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search movies…"
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-white dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all font-body"
            />
          </div>

          <button
            onClick={() => setShowFilters(v => !v)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg border text-sm font-body transition-all ${
              showFilters || langFilter
                ? 'bg-brand-50 dark:bg-brand-500/10 border-brand-300 dark:border-brand-500/30 text-brand-600 dark:text-brand-400'
                : 'bg-white dark:bg-cinema-800 border-gray-200 dark:border-white/10 text-gray-600 dark:text-gray-400 hover:border-gray-300 dark:hover:border-white/20'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filter
            {langFilter && <span className="w-1.5 h-1.5 rounded-full bg-brand-500 ml-0.5" />}
          </button>

          {someChecked && (
            <button
              onClick={() => setBulkDeleteOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg border text-sm font-body bg-red-50 dark:bg-red-500/10 border-red-200 dark:border-red-500/20 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-500/20 transition-all"
            >
              <Trash2 className="w-4 h-4" />
              Delete {selected.size}
            </button>
          )}

          <button
            onClick={refetch}
            className="p-2.5 rounded-lg border border-gray-200 dark:border-white/10 bg-white dark:bg-cinema-800 text-gray-500 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 hover:border-brand-500/30 transition-all ml-auto"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <div className="flex flex-wrap gap-3 p-4 bg-white dark:bg-cinema-900 border border-gray-200 dark:border-white/10 rounded-xl">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-gray-400 uppercase tracking-wider">Language</label>
              <select
                value={langFilter}
                onChange={e => setLangFilter(e.target.value)}
                className="px-3 py-2 text-sm bg-gray-50 dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500/30 font-body"
              >
                <option value="">All Languages</option>
                {languages.map(l => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-gray-400 uppercase tracking-wider">Sort By</label>
              <select
                value={sortField}
                onChange={e => setSortField(e.target.value as SortField)}
                className="px-3 py-2 text-sm bg-gray-50 dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500/30 font-body"
              >
                <option value="created_at">Date Added</option>
                <option value="title">Title</option>
                <option value="release_year">Release Year</option>
                <option value="language">Language</option>
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-mono text-gray-400 uppercase tracking-wider">Order</label>
              <select
                value={sortDir}
                onChange={e => setSortDir(e.target.value as SortDir)}
                className="px-3 py-2 text-sm bg-gray-50 dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500/30 font-body"
              >
                <option value="desc">Descending</option>
                <option value="asc">Ascending</option>
              </select>
            </div>
            {langFilter && (
              <div className="flex flex-col gap-1.5 justify-end">
                <button
                  onClick={() => setLangFilter('')}
                  className="px-3 py-2 text-sm text-red-500 hover:text-red-600 font-body transition-colors"
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>
        )}

        {/* Table */}
        <div className="bg-white dark:bg-cinema-900 rounded-2xl border border-gray-200 dark:border-white/10 overflow-hidden shadow-sm">
          {error && <div className="p-6 text-center text-sm text-red-500 font-body">{error}</div>}

          {loading && !error && (
            <div className="p-12 flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {!loading && !error && filtered.length === 0 && (
            <div className="p-12 text-center">
              <Film className="w-10 h-10 text-gray-200 dark:text-gray-700 mx-auto mb-3" />
              <p className="text-gray-400 dark:text-gray-500 text-sm font-body">
                {search || langFilter ? 'No movies match your filters.' : 'No movies yet. Add your first movie!'}
              </p>
            </div>
          )}

          {!loading && !error && filtered.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100 dark:border-white/5">
                    <th className="px-4 py-3 w-10">
                      <button onClick={toggleAll} className="text-gray-400 hover:text-brand-500 transition-colors">
                        {allChecked
                          ? <CheckSquare className="w-4 h-4 text-brand-500" />
                          : someChecked
                          ? <CheckSquare className="w-4 h-4 text-brand-300" />
                          : <Square className="w-4 h-4" />
                        }
                      </button>
                    </th>
                    <th
                      className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider cursor-pointer hover:text-brand-500 transition-colors"
                      onClick={() => handleSort('title')}
                    >
                      <div className="flex items-center gap-1">Movie <SortIcon field="title" /></div>
                    </th>
                    <th
                      className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider cursor-pointer hover:text-brand-500 transition-colors hidden sm:table-cell"
                      onClick={() => handleSort('release_year')}
                    >
                      <div className="flex items-center gap-1">Year <SortIcon field="release_year" /></div>
                    </th>
                    <th
                      className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider cursor-pointer hover:text-brand-500 transition-colors hidden md:table-cell"
                      onClick={() => handleSort('language')}
                    >
                      <div className="flex items-center gap-1">Language <SortIcon field="language" /></div>
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider hidden lg:table-cell">Folders</th>
                    <th className="px-4 py-3 text-right text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                  {filtered.map(movie => (
                    <tr
                      key={movie.id}
                      className={`hover:bg-gray-50 dark:hover:bg-cinema-800/50 transition-colors ${
                        selected.has(movie.id) ? 'bg-brand-50/50 dark:bg-brand-500/5' : ''
                      }`}
                    >
                      <td className="px-4 py-3">
                        <button
                          onClick={() => toggleOne(movie.id)}
                          className="text-gray-400 hover:text-brand-500 transition-colors"
                        >
                          {selected.has(movie.id)
                            ? <CheckSquare className="w-4 h-4 text-brand-500" />
                            : <Square className="w-4 h-4" />
                          }
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-11 rounded overflow-hidden bg-gray-100 dark:bg-cinema-700 shrink-0">
                            {movie.poster_url
                              ? <img src={movie.poster_url} alt="" className="w-full h-full object-cover" />
                              : <div className="w-full h-full flex items-center justify-center"><Film className="w-3.5 h-3.5 text-gray-400" /></div>
                            }
                          </div>
                          <div>
                            <p className="font-body font-medium text-sm text-gray-900 dark:text-white line-clamp-1">{movie.title}</p>
                            <p className="text-xs text-gray-400 dark:text-gray-500 sm:hidden">{movie.release_year} · {movie.language}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400 font-mono hidden sm:table-cell">{movie.release_year}</td>
                      <td className="px-4 py-3 hidden md:table-cell">
                        <span className="text-xs font-body px-2 py-1 rounded-md bg-gray-100 dark:bg-cinema-700 text-gray-600 dark:text-gray-400">
                          {movie.language}
                        </span>
                      </td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <div className="flex gap-2">
                          <a href={movie.dialogues_folder_url} target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs px-2 py-1 rounded-md bg-brand-50 dark:bg-brand-500/10 text-brand-600 dark:text-brand-400 border border-brand-100 dark:border-brand-500/20 hover:bg-brand-100 dark:hover:bg-brand-500/20 transition-colors font-body">
                            Dialogues <ExternalLink className="w-3 h-3" />
                          </a>
                          <a href={movie.slowmo_folder_url} target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs px-2 py-1 rounded-md bg-gray-50 dark:bg-cinema-700 text-gray-600 dark:text-gray-400 border border-gray-100 dark:border-white/5 hover:bg-gray-100 dark:hover:bg-cinema-600 transition-colors font-body">
                            Slow Mo <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setEditMovie(movie)}
                            className="p-2 rounded-lg text-gray-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-500/10 transition-all"
                            title="Edit"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteTarget(movie)}
                            className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Table footer */}
              <div className="px-4 py-3 border-t border-gray-100 dark:border-white/5 flex items-center justify-between">
                <p className="text-xs font-body text-gray-400 dark:text-gray-500">
                  Showing {filtered.length} of {movies.length} movies
                  {selected.size > 0 && ` · ${selected.size} selected`}
                </p>
                {selected.size > 0 && (
                  <button
                    onClick={() => setSelected(new Set())}
                    className="text-xs font-body text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                  >
                    Clear selection
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Add New Movie" size="lg">
        <MovieForm onSubmit={handleAdd} onCancel={() => setAddOpen(false)} loading={saving} />
      </Modal>

      <Modal open={!!editMovie} onClose={() => setEditMovie(null)} title="Edit Movie" size="lg">
        {editMovie && (
          <MovieForm initial={editMovie} onSubmit={handleEdit} onCancel={() => setEditMovie(null)} loading={saving} />
        )}
      </Modal>

      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete Movie" size="sm">
        <div className="space-y-4">
          <p className="text-sm font-body text-gray-600 dark:text-gray-300">
            Are you sure you want to delete{' '}
            <strong className="text-gray-900 dark:text-white">{deleteTarget?.title}</strong>?
            This cannot be undone.
          </p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={handleDelete} loading={deleting} className="flex-1">Delete</Button>
            <Button variant="secondary" onClick={() => setDeleteTarget(null)} disabled={deleting}>Cancel</Button>
          </div>
        </div>
      </Modal>

      <Modal open={bulkDeleteOpen} onClose={() => setBulkDeleteOpen(false)} title="Delete Selected Movies" size="sm">
        <div className="space-y-4">
          <p className="text-sm font-body text-gray-600 dark:text-gray-300">
            You're about to delete{' '}
            <strong className="text-gray-900 dark:text-white">{selected.size} movies</strong>.
            This cannot be undone.
          </p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={handleBulkDelete} loading={deleting} className="flex-1">
              Delete All {selected.size}
            </Button>
            <Button variant="secondary" onClick={() => setBulkDeleteOpen(false)} disabled={deleting}>Cancel</Button>
          </div>
        </div>
      </Modal>
    </AdminLayout>
  )
}
