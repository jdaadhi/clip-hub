import { useState } from 'react'
import { Movie, MovieInsert } from '@/types'
import { Button } from '@/components/ui/Button'
import { Film, ImageOff } from 'lucide-react'

interface MovieFormProps {
  initial?: Movie
  onSubmit: (data: MovieInsert) => Promise<void>
  onCancel: () => void
  loading?: boolean
}

const EMPTY: MovieInsert = {
  title: '',
  poster_url: '',
  release_year: new Date().getFullYear(),
  language: '',
  dialogues_folder_url: '',
  slowmo_folder_url: '',
}

interface FieldProps {
  label: string
  required?: boolean
  children: React.ReactNode
  hint?: string
  error?: string
}

function Field({ label, required, children, hint, error }: FieldProps) {
  return (
    <div className="space-y-1.5">
      <label className="block text-sm font-body font-medium text-gray-700 dark:text-gray-300">
        {label} {required && <span className="text-brand-500">*</span>}
      </label>
      {children}
      {hint && !error && <p className="text-xs text-gray-400 dark:text-gray-500 font-body">{hint}</p>}
      {error && <p className="text-xs text-red-500 font-body">{error}</p>}
    </div>
  )
}

const inputCls = `
  w-full px-3.5 py-2.5 rounded-lg text-sm font-body
  bg-white dark:bg-cinema-800
  border border-gray-200 dark:border-white/10
  text-gray-900 dark:text-white
  placeholder-gray-400 dark:placeholder-gray-500
  focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500
  transition-all
`

const COMMON_LANGUAGES = ['Tamil', 'Telugu', 'Hindi', 'Malayalam', 'Kannada', 'English', 'Korean', 'Japanese']

export function MovieForm({ initial, onSubmit, onCancel, loading }: MovieFormProps) {
  const [form, setForm] = useState<MovieInsert>(
    initial
      ? {
          title: initial.title,
          poster_url: initial.poster_url,
          release_year: initial.release_year,
          language: initial.language,
          dialogues_folder_url: initial.dialogues_folder_url,
          slowmo_folder_url: initial.slowmo_folder_url,
        }
      : EMPTY
  )
  const [errors, setErrors] = useState<Partial<Record<keyof MovieInsert, string>>>({})
  const [posterError, setPosterError] = useState(false)

  const set = (key: keyof MovieInsert) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm(prev => ({ ...prev, [key]: key === 'release_year' ? Number(e.target.value) : e.target.value }))
    if (errors[key]) setErrors(prev => ({ ...prev, [key]: '' }))
    if (key === 'poster_url') setPosterError(false)
  }

  const validate = () => {
    const errs: typeof errors = {}
    if (!form.title.trim()) errs.title = 'Title is required'
    if (!form.language.trim()) errs.language = 'Language is required'
    if (!form.release_year || form.release_year < 1900 || form.release_year > 2100)
      errs.release_year = 'Enter a valid year'
    if (!form.dialogues_folder_url.trim()) errs.dialogues_folder_url = 'Dialogues folder URL is required'
    if (!form.slowmo_folder_url.trim()) errs.slowmo_folder_url = 'Slow motion folder URL is required'
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return
    await onSubmit(form)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex gap-4">
        {/* Poster preview */}
        <div className="shrink-0">
          <div className="w-20 h-28 rounded-xl overflow-hidden bg-gray-100 dark:bg-cinema-700 border border-gray-200 dark:border-white/10 flex items-center justify-center">
            {form.poster_url && !posterError ? (
              <img
                src={form.poster_url}
                alt="Poster preview"
                className="w-full h-full object-cover"
                onError={() => setPosterError(true)}
              />
            ) : (
              <div className="flex flex-col items-center gap-1 text-gray-300 dark:text-gray-600">
                {posterError
                  ? <ImageOff className="w-6 h-6" />
                  : <Film className="w-6 h-6" />
                }
                <span className="text-[9px] font-mono uppercase tracking-wider">
                  {posterError ? 'Bad URL' : 'Poster'}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Title + year + lang */}
        <div className="flex-1 space-y-3 min-w-0">
          <Field label="Movie Title" required error={errors.title}>
            <input className={inputCls} placeholder="e.g. Inception" value={form.title} onChange={set('title')} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Year" required error={errors.release_year}>
              <input
                type="number"
                className={inputCls}
                placeholder="2024"
                value={form.release_year}
                onChange={set('release_year')}
                min={1900}
                max={2100}
              />
            </Field>
            <Field label="Language" required error={errors.language}>
              <select
                className={inputCls}
                value={COMMON_LANGUAGES.includes(form.language) ? form.language : '__custom__'}
                onChange={e => {
                  if (e.target.value !== '__custom__') {
                    setForm(prev => ({ ...prev, language: e.target.value }))
                    if (errors.language) setErrors(prev => ({ ...prev, language: '' }))
                  }
                }}
              >
                <option value="">Select…</option>
                {COMMON_LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                <option value="__custom__">Other…</option>
              </select>
              {(!COMMON_LANGUAGES.includes(form.language) || form.language === '') && (
                <input
                  className={`${inputCls} mt-1.5`}
                  placeholder="Type language…"
                  value={form.language}
                  onChange={set('language')}
                />
              )}
            </Field>
          </div>
        </div>
      </div>

      <Field label="Poster URL" hint="Direct image URL for the movie poster">
        <input
          className={inputCls}
          placeholder="https://example.com/poster.jpg"
          value={form.poster_url}
          onChange={set('poster_url')}
        />
      </Field>

      <Field
        label="Google Drive — Dialogues Folder"
        required
        hint="Share link to the Google Drive folder containing dialogue clips"
        error={errors.dialogues_folder_url}
      >
        <input
          className={inputCls}
          placeholder="https://drive.google.com/drive/folders/..."
          value={form.dialogues_folder_url}
          onChange={set('dialogues_folder_url')}
        />
      </Field>

      <Field
        label="Google Drive — Slow Motion Folder"
        required
        hint="Share link to the Google Drive folder containing slow motion clips"
        error={errors.slowmo_folder_url}
      >
        <input
          className={inputCls}
          placeholder="https://drive.google.com/drive/folders/..."
          value={form.slowmo_folder_url}
          onChange={set('slowmo_folder_url')}
        />
      </Field>

      <div className="flex gap-3 pt-2">
        <Button type="submit" loading={loading} className="flex-1">
          {initial ? 'Save Changes' : 'Add Movie'}
        </Button>
        <Button type="button" variant="secondary" onClick={onCancel} disabled={loading}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
