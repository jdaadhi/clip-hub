import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, MessageSquare, Zap, Calendar, Globe, ExternalLink, Film } from 'lucide-react'
import { useMovie } from '@/hooks/useMovies'
import { Button } from '@/components/ui/Button'

export function MoviePage() {
  const { id } = useParams<{ id: string }>()
  const { movie, loading, error } = useMovie(id!)

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-cinema-950 flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (error || !movie) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-cinema-950 flex items-center justify-center">
        <div className="text-center px-4">
          <div className="w-16 h-16 rounded-2xl bg-gray-100 dark:bg-cinema-800 flex items-center justify-center mx-auto mb-4">
            <Film className="w-8 h-8 text-gray-300 dark:text-gray-600" />
          </div>
          <h2 className="font-body font-semibold text-gray-900 dark:text-white mb-2">Movie not found</h2>
          <p className="text-gray-400 dark:text-gray-500 text-sm mb-6">{error ?? 'This movie does not exist.'}</p>
          <Link to="/">
            <Button variant="secondary" icon={<ArrowLeft className="w-4 h-4" />}>Back to Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-cinema-950 animate-fade-in">
      {/* Hero backdrop */}
      <div className="relative">
        {movie.poster_url && (
          <div className="absolute inset-0 overflow-hidden h-80 sm:h-96">
            <img
              src={movie.poster_url}
              alt=""
              className="w-full h-full object-cover blur-2xl scale-110 opacity-20 dark:opacity-10"
              aria-hidden
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-gray-50 dark:to-cinema-950" />
          </div>
        )}

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-0">
          {/* Back nav */}
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 text-sm font-body text-gray-500 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 transition-colors mb-8"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Library
          </Link>

          {/* Movie details card */}
          <div className="flex flex-col sm:flex-row gap-6 sm:gap-8">
            {/* Poster */}
            <div className="shrink-0 mx-auto sm:mx-0">
              <div className="w-40 sm:w-52 aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl shadow-black/30 border border-white/10 bg-gray-200 dark:bg-cinema-800">
                {movie.poster_url ? (
                  <img
                    src={movie.poster_url}
                    alt={movie.title}
                    className="w-full h-full object-cover"
                    onError={e => {
                      e.currentTarget.style.display = 'none'
                    }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <span className="font-display text-5xl text-gray-400 dark:text-gray-600">
                      {movie.title[0]}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 pb-6">
              <h1 className="font-display text-3xl sm:text-5xl text-gray-900 dark:text-white tracking-wider leading-none mb-4">
                {movie.title}
              </h1>

              <div className="flex flex-wrap gap-3 mb-6">
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gray-100 dark:bg-cinema-800 text-sm font-body text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-white/10">
                  <Calendar className="w-3.5 h-3.5 text-brand-500" />
                  {movie.release_year}
                </span>
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-gray-100 dark:bg-cinema-800 text-sm font-body text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-white/10">
                  <Globe className="w-3.5 h-3.5 text-brand-500" />
                  {movie.language}
                </span>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={movie.dialogues_folder_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-body font-semibold text-sm transition-all shadow-lg shadow-brand-500/25 hover:shadow-brand-600/30 hover:-translate-y-0.5 active:translate-y-0"
                >
                  <MessageSquare className="w-4.5 h-4.5" />
                  View Dialogues
                  <ExternalLink className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 transition-opacity" />
                </a>

                <a
                  href={movie.slowmo_folder_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-white dark:bg-cinema-800 hover:bg-gray-50 dark:hover:bg-cinema-700 text-gray-900 dark:text-white font-body font-semibold text-sm border border-gray-200 dark:border-white/10 hover:border-brand-500/40 transition-all hover:-translate-y-0.5 active:translate-y-0"
                >
                  <Zap className="w-4.5 h-4.5 text-brand-500" />
                  Slow Motion Clips
                  <ExternalLink className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 transition-opacity" />
                </a>
              </div>

              <p className="mt-4 text-xs text-gray-400 dark:text-gray-500 font-body">
                Both folders open in Google Drive in a new tab.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
