export interface Movie {
  id: string
  title: string
  poster_url: string
  release_year: number
  language: string
  dialogues_folder_url: string
  slowmo_folder_url: string
  created_at: string
}

export type MovieInsert = Omit<Movie, 'id' | 'created_at'>
export type MovieUpdate = Partial<MovieInsert>

export interface AdminUser {
  id: string
  email: string
  created_at: string
}

export interface AuthState {
  user: import('@supabase/supabase-js').User | null
  isAdmin: boolean
  loading: boolean
}
