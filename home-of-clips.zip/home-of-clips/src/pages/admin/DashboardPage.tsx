import { useState } from 'react'
import { Plus, Pencil, Trash2, Film, Search, ExternalLink, RefreshCw } from 'lucide-react'
import { useMovies, createMovie, updateMovie, deleteMovie } from '@/hooks/useMovies'
import { Movie, MovieInsert } from '@/types'
import { Button } from '@/components/ui/Button'
import { Modal } from '@/components/ui/Modal'
import { MovieForm } from '@/components/admin/MovieForm'
import { useToast } from '@/components/ui/Toast'

export function DashboardPage() {
  const { movies, loading, error, refetch } = useMovies()
  const { toast } = useToast()
  const [search, setSearch] = useState('')
  const [addOpen, setAddOpen] = useState(false)
  const [editMovie, setEditMovie] = useState<Movie | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Movie | null>(null)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const filtered = movies.filter(m =>
    m.title.toLowerCase().includes(search.toLowerCase())
  )

  const handleAdd = async (data: MovieInsert) => {
    setSaving(true)
    const { error: err } = await createMovie(data)
    setSaving(false)
    if (err) {
      toast(err.message, 'error')
    } else {
      toast('Movie added successfully!', 'success')
      setAddOpen(false)
      refetch()
    }
  }

  const handleEdit = async (data: MovieInsert) => {
    if (!editMovie) return
    setSaving(true)
    const { error: err } = await updateMovie(editMovie.id, data)
    setSaving(false)
    if (err) {
      toast(err.message, 'error')
    } else {
      toast('Movie updated!', 'success')
      setEditMovie(null)
      refetch()
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    const { error: err } = await deleteMovie(deleteTarget.id)
    setDeleting(false)
    if (err) {
      toast(err.message, 'error')
    } else {
      toast('Movie deleted.', 'success')
      setDeleteTarget(null)
      refetch()
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-cinema-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="font-display text-3xl text-gray-900 dark:text-white tracking-wider">DASHBOARD</h1>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-body mt-0.5">
              Manage your movie library · {movies.length} {movies.length === 1 ? 'movie' : 'movies'}
            </p>
          </div>
          <Button onClick={() => setAddOpen(true)} icon={<Plus className="w-4 h-4" />}>
            Add Movie
          </Button>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Filter movies…"
              className="w-full pl-10 pr-4 py-2.5 text-sm bg-white dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500 transition-all font-body"
            />
          </div>
          <button
            onClick={refetch}
            className="p-2.5 rounded-lg border border-gray-200 dark:border-white/10 bg-white dark:bg-cinema-800 text-gray-500 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 hover:border-brand-500/30 transition-all"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Table */}
        <div className="bg-white dark:bg-cinema-900 rounded-2xl border border-gray-200 dark:border-white/10 overflow-hidden shadow-sm">
          {error && (
            <div className="p-6 text-center text-sm text-red-500 font-body">{error}</div>
          )}

          {loading && !error && (
            <div className="p-12 flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {!loading && !error && filtered.length === 0 && (
            <div className="p-12 text-center">
              <Film className="w-10 h-10 text-gray-200 dark:text-gray-700 mx-auto mb-3" />
              <p className="text-gray-400 dark:text-gray-500 text-sm font-body">
                {search ? 'No movies match your filter.' : 'No movies yet. Add your first movie!'}
              </p>
            </div>
          )}

          {!loading && !error && filtered.length > 0 && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100 dark:border-white/5">
                    <th className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">Movie</th>
                    <th className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider hidden sm:table-cell">Year</th>
                    <th className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider hidden md:table-cell">Language</th>
                    <th className="px-4 py-3 text-left text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider hidden lg:table-cell">Folders</th>
                    <th className="px-4 py-3 text-right text-xs font-mono font-medium text-gray-400 dark:text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50 dark:divide-white/5">
                  {filtered.map(movie => (
                    <tr key={movie.id} className="hover:bg-gray-50 dark:hover:bg-cinema-800/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-11 rounded overflow-hidden bg-gray-100 dark:bg-cinema-700 shrink-0">
                            {movie.poster_url ? (
                              <img src={movie.poster_url} alt="" className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <Film className="w-3.5 h-3.5 text-gray-400" />
                              </div>
                            )}
                          </div>
                          <div>
                            <p className="font-body font-medium text-sm text-gray-900 dark:text-white line-clamp-1">{movie.title}</p>
                            <p className="text-xs text-gray-400 dark:text-gray-500 sm:hidden">{movie.release_year} · {movie.language}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400 font-mono hidden sm:table-cell">{movie.release_year}</td>
                      <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400 font-body hidden md:table-cell">{movie.language}</td>
                      <td className="px-4 py-3 hidden lg:table-cell">
                        <div className="flex gap-2">
                          <a href={movie.dialogues_folder_url} target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs px-2 py-1 rounded-md bg-brand-50 dark:bg-brand-500/10 text-brand-600 dark:text-brand-400 border border-brand-100 dark:border-brand-500/20 hover:bg-brand-100 dark:hover:bg-brand-500/20 transition-colors font-body">
                            Dialogues <ExternalLink className="w-3 h-3" />
                          </a>
                          <a href={movie.slowmo_folder_url} target="_blank" rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs px-2 py-1 rounded-md bg-gray-50 dark:bg-cinema-700 text-gray-600 dark:text-gray-400 border border-gray-100 dark:border-white/5 hover:bg-gray-100 dark:hover:bg-cinema-600 transition-colors font-body">
                            Slow Mo <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setEditMovie(movie)}
                            className="p-2 rounded-lg text-gray-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-500/10 transition-all"
                            title="Edit"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteTarget(movie)}
                            className="p-2 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-all"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Add Modal */}
      <Modal open={addOpen} onClose={() => setAddOpen(false)} title="Add New Movie" size="lg">
        <MovieForm onSubmit={handleAdd} onCancel={() => setAddOpen(false)} loading={saving} />
      </Modal>

      {/* Edit Modal */}
      <Modal open={!!editMovie} onClose={() => setEditMovie(null)} title="Edit Movie" size="lg">
        {editMovie && (
          <MovieForm
            initial={editMovie}
            onSubmit={handleEdit}
            onCancel={() => setEditMovie(null)}
            loading={saving}
          />
        )}
      </Modal>

      {/* Delete Confirm */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete Movie" size="sm">
        <div className="space-y-4">
          <p className="text-sm font-body text-gray-600 dark:text-gray-300">
            Are you sure you want to delete{' '}
            <strong className="text-gray-900 dark:text-white">{deleteTarget?.title}</strong>?
            This action cannot be undone.
          </p>
          <div className="flex gap-3">
            <Button variant="danger" onClick={handleDelete} loading={deleting} className="flex-1">
              Delete
            </Button>
            <Button variant="secondary" onClick={() => setDeleteTarget(null)} disabled={deleting}>
              Cancel
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  )
}
