import { useState } from 'react'
import {
  Database, ExternalLink, Copy, Check, Globe, Info,
  ShieldCheck, Zap, BookOpen
} from 'lucide-react'
import { useMovies } from '@/hooks/useMovies'
import { useAdminUsers } from '@/hooks/useAdminUsers'
import { AdminLayout } from '@/components/admin/AdminLayout'

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button
      onClick={handleCopy}
      className="p-1.5 rounded-md text-gray-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-500/10 transition-all"
      title="Copy"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
    </button>
  )
}

function InfoCard({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-cinema-900 rounded-2xl border border-gray-200 dark:border-white/10 overflow-hidden shadow-sm">
      <div className="flex items-center gap-2.5 px-5 py-4 border-b border-gray-100 dark:border-white/5">
        <span className="text-brand-500 dark:text-brand-400">{icon}</span>
        <h2 className="font-body font-semibold text-gray-900 dark:text-white text-sm">{title}</h2>
      </div>
      <div className="px-5 py-4">{children}</div>
    </div>
  )
}

export function SettingsPage() {
  const { movies } = useMovies()
  const { admins } = useAdminUsers()

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL ?? ''
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY ?? ''
  const isConfigured = !!supabaseUrl && !!anonKey

  const maskedKey = anonKey
    ? anonKey.slice(0, 20) + '••••••••••••••••••••' + anonKey.slice(-6)
    : '(not set)'

  return (
    <AdminLayout movieCount={movies.length} adminCount={admins.length}>
      <div className="p-6 lg:p-8 max-w-3xl mx-auto space-y-6">

        {/* Header */}
        <div>
          <h1 className="font-display text-2xl text-gray-900 dark:text-white tracking-wider">SETTINGS</h1>
          <p className="text-gray-400 dark:text-gray-500 text-sm font-body mt-0.5">Project configuration and environment info</p>
        </div>

        {/* Connection Status */}
        <InfoCard icon={<Database className="w-4.5 h-4.5" />} title="Supabase Connection">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConfigured ? 'bg-green-500' : 'bg-red-500'} animate-pulse`} />
              <span className={`text-sm font-body font-medium ${isConfigured ? 'text-green-600 dark:text-green-400' : 'text-red-500'}`}>
                {isConfigured ? 'Connected' : 'Not configured'}
              </span>
            </div>

            <div className="space-y-3">
              <div className="space-y-1.5">
                <p className="text-xs font-mono text-gray-400 uppercase tracking-wider">Supabase URL</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 px-3 py-2 text-xs font-mono bg-gray-50 dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-700 dark:text-gray-300 truncate">
                    {supabaseUrl || '(not set — add VITE_SUPABASE_URL to .env)'}
                  </code>
                  {supabaseUrl && (
                    <>
                      <CopyButton text={supabaseUrl} />
                      <a href={supabaseUrl} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-md text-gray-400 hover:text-brand-500 transition-colors">
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </>
                  )}
                </div>
              </div>

              <div className="space-y-1.5">
                <p className="text-xs font-mono text-gray-400 uppercase tracking-wider">Anon Key</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 px-3 py-2 text-xs font-mono bg-gray-50 dark:bg-cinema-800 border border-gray-200 dark:border-white/10 rounded-lg text-gray-700 dark:text-gray-300 truncate">
                    {maskedKey}
                  </code>
                  {anonKey && <CopyButton text={anonKey} />}
                </div>
              </div>
            </div>

            {!isConfigured && (
              <div className="p-3 bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 rounded-lg">
                <p className="text-xs font-body text-amber-700 dark:text-amber-400">
                  Create a <code className="font-mono">.env</code> file in your project root with{' '}
                  <code className="font-mono">VITE_SUPABASE_URL</code> and{' '}
                  <code className="font-mono">VITE_SUPABASE_ANON_KEY</code> from your Supabase project settings.
                </p>
              </div>
            )}
          </div>
        </InfoCard>

        {/* Database Stats */}
        <InfoCard icon={<Zap className="w-4.5 h-4.5" />} title="Database Overview">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {[
              { label: 'Movies', value: movies.length },
              { label: 'Admins', value: admins.length },
              { label: 'Drive Folders', value: movies.length * 2 },
            ].map(stat => (
              <div key={stat.label} className="text-center p-3 bg-gray-50 dark:bg-cinema-800 rounded-xl">
                <p className="font-display text-2xl text-gray-900 dark:text-white">{stat.value}</p>
                <p className="text-xs font-body text-gray-400 mt-0.5">{stat.label}</p>
              </div>
            ))}
          </div>
        </InfoCard>

        {/* Environment Vars */}
        <InfoCard icon={<Globe className="w-4.5 h-4.5" />} title="Environment Variables">
          <div className="space-y-3">
            <p className="text-xs font-body text-gray-500 dark:text-gray-400">
              Add these to your <code className="font-mono text-brand-500">.env</code> file (or Netlify / Vercel environment settings):
            </p>
            <div className="relative">
              <pre className="px-4 py-3.5 bg-gray-900 dark:bg-black rounded-xl text-xs font-mono text-green-400 overflow-x-auto leading-relaxed">
{`VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGc...`}
              </pre>
              <div className="absolute top-2 right-2">
                <CopyButton text={`VITE_SUPABASE_URL=https://xxxx.supabase.co\nVITE_SUPABASE_ANON_KEY=eyJhbGc...`} />
              </div>
            </div>
          </div>
        </InfoCard>

        {/* Setup Checklist */}
        <InfoCard icon={<ShieldCheck className="w-4.5 h-4.5" />} title="Setup Checklist">
          <ul className="space-y-3">
            {[
              { done: isConfigured, label: 'Add Supabase URL and anon key to .env' },
              { done: movies.length > 0, label: 'Add your first movie to the database' },
              { done: admins.length > 0, label: 'Add at least one admin email' },
              { done: admins.length > 0 && isConfigured, label: 'Run the SQL migration in Supabase dashboard' },
            ].map((item, i) => (
              <li key={i} className="flex items-center gap-3">
                <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${
                  item.done
                    ? 'bg-green-100 dark:bg-green-500/20'
                    : 'bg-gray-100 dark:bg-cinema-700'
                }`}>
                  {item.done
                    ? <Check className="w-3 h-3 text-green-600 dark:text-green-400" />
                    : <span className="w-1.5 h-1.5 rounded-full bg-gray-400 dark:bg-gray-500" />
                  }
                </div>
                <span className={`text-sm font-body ${item.done ? 'text-gray-700 dark:text-gray-300' : 'text-gray-400 dark:text-gray-500'}`}>
                  {item.label}
                </span>
              </li>
            ))}
          </ul>
        </InfoCard>

        {/* Docs links */}
        <InfoCard icon={<BookOpen className="w-4.5 h-4.5" />} title="Quick Links">
          <div className="space-y-2">
            {[
              { label: 'Supabase Dashboard', url: supabaseUrl ? `${supabaseUrl.replace('.supabase.co', '')}.supabase.com` : 'https://supabase.com/dashboard' },
              { label: 'Supabase SQL Editor', url: 'https://supabase.com/dashboard/project/_/sql' },
              { label: 'Supabase Auth → Users', url: 'https://supabase.com/dashboard/project/_/auth/users' },
            ].map(link => (
              <a
                key={link.label}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between px-3.5 py-2.5 rounded-lg bg-gray-50 dark:bg-cinema-800 hover:bg-brand-50 dark:hover:bg-brand-500/10 hover:text-brand-600 dark:hover:text-brand-400 text-gray-700 dark:text-gray-300 text-sm font-body transition-all group"
              >
                {link.label}
                <ExternalLink className="w-3.5 h-3.5 text-gray-300 group-hover:text-brand-400 transition-colors" />
              </a>
            ))}
          </div>
        </InfoCard>

        {/* Version */}
        <div className="text-center">
          <p className="text-xs font-mono text-gray-400 dark:text-gray-600">
            Home of Clips · Admin Panel v2.0
          </p>
        </div>
      </div>
    </AdminLayout>
  )
}
